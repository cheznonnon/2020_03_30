// Nonnon COM : HTMLDocumentEvents
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed


// [!] : Compatibility
//
//	[ IE4 ]
//	supports HTMLDocumentEvents only
//	DISPID_ONCONTEXTMENU never comes


// [Mechanism]
//
//	return VARIANT_FALSE;
//	click/menu/wheeling/... will be suppressed
//
//	#10xx      : DISPID_NORMAL_FIRST
//	0x8001000x : DISPID_XOBJ_BASE




#ifndef _H_NONNON_WIN32_COM_HTMLDOCUMENTEVENTS
#define _H_NONNON_WIN32_COM_HTMLDOCUMENTEVENTS




#include <olectl.h>
//#include <mshtmdid.h>




HRESULT __stdcall
n_HTMLDocumentEvents_IUnknown_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{
N_COM_DEBUG_LISTBOX_SET_A( "HTMLDocumentEvents_IUnknown_QueryInterface" );


	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID d = n_com_guid( n_guid_IID_IDispatch );
	GUID w = n_com_guid( n_guid_DIID_HTMLDocumentEvents );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &d ) )
		||
		( IsEqualGUID( iid, &w ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}




HRESULT __stdcall
n_HTMLDocumentEvents_IDispatch_Invoke
(
	void         *_this,
	DISPID        dispIdMember,
	REFIID        riid,
	LCID          lcid,
	WORD          wFlags,
	DISPPARAMS   *pDispParams,
	VARIANT      *pVarResult,
	EXCEPINFO    *pExcepInfo,
	unsigned int *puArgErr
)
{

	if ( pVarResult != NULL )
	{
		V_VT  ( pVarResult ) = VT_BOOL;
		V_BOOL( pVarResult ) = VARIANT_TRUE;
	}


	switch( dispIdMember ) {


	case DISPID_CLICK :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_CLICK " );
	break;

	case DISPID_DBLCLICK :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_DBLCLICK " );
	break;

	case DISPID_KEYDOWN :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_KEYDOWN " );
	break;

	case DISPID_KEYPRESS :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_KEYPRESS " );
	break;

	case DISPID_KEYUP :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_KEYUP " );
	break;

	case DISPID_MOUSEDOWN :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_MOUSEDOWN " );
	break;

	case DISPID_MOUSEMOVE :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_MOUSEMOVE " );
	break;

	case DISPID_MOUSEUP :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_MOUSEUP " );
	break;

	case DISPID_READYSTATECHANGE :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_READYSTATECHANGE " );

	break;




	case DISPID_ONCONTEXTMENU :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_ONCONTEXTMENU " );
	break;

	case DISPID_ONSTOP :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_ONSTOP " );
	break;

	case DISPID_ONBEFOREEDITFOCUS :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_ONBEFOREEDITFOCUS " );
	break;

	case DISPID_ONMOUSEWHEEL :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_ONMOUSEWHEEL " );
	break;

	case DISPID_ONBEFOREDEACTIVATE :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_ONBEFOREDEACTIVATE " );
	break;

	case DISPID_ONSELECTIONCHANGE :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_ONSELECTIONCHANGE " );
	break;

	case DISPID_ONACTIVATE :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_ONACTIVATE " );
	break;

	case DISPID_ONDEACTIVATE :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_ONDEACTIVATE " );
	break;

	case DISPID_ONBEFOREACTIVATE :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_ONBEFOREACTIVATE " );
	break;

	case DISPID_ONFOCUSIN :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_ONFOCUSIN " );
	break;

	case DISPID_ONFOCUSOUT :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : DISPID_ONFOCUSOUT " );
	break;




	case STDDISPID_XOBJ_ONMOUSEOVER :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : STDDISPID_XOBJ_ONMOUSEOVER " );

		// [!] : a cursor move into a client area

		// [!] : VARIANT_TRUE interferes status text change

		V_BOOL( pVarResult ) = VARIANT_FALSE;

	break;

	case STDDISPID_XOBJ_ONMOUSEOUT :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : STDDISPID_XOBJ_ONMOUSEOUT " );
	break;

	case STDDISPID_XOBJ_ONHELP :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : STDDISPID_XOBJ_ONHELP " );

		// [!] : F1 key is pressed

	break;

	case STDDISPID_XOBJ_ONSELECTSTART :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : STDDISPID_XOBJ_ONSELECTSTART " );
	break;

	case STDDISPID_XOBJ_ONPROPERTYCHANGE :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : STDDISPID_XOBJ_ONPROPERTYCHANGE " );
	break;

	case STDDISPID_XOBJ_ONBEFORECUT :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : STDDISPID_XOBJ_ONBEFORECUT " );
	break;

	case STDDISPID_XOBJ_ONCOPY :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : STDDISPID_XOBJ_ONCOPY " );
	break;

	case STDDISPID_XOBJ_ONPASTE :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : STDDISPID_XOBJ_ONPASTE " );
	break;

	case STDDISPID_XOBJ_ONBEFORECOPY :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : STDDISPID_XOBJ_ONBEFORECOPY " );
	break;

	case STDDISPID_XOBJ_ONBEFOREPASTE :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLDocumentEvents : STDDISPID_XOBJ_ONBEFOREPASTE " );
	break;




	default :
	{
char str[ 100 ];
sprintf( str, "DISP_E_MEMBERNOTFOUND : %08x : %d", (int) dispIdMember, (int) dispIdMember );
N_COM_DEBUG_LISTBOX_SET_A( str );

		return DISP_E_MEMBERNOTFOUND;

	}
	break;


	} // switch


	return S_OK;
}




const void *n_HTMLDocumentEvents_Vtbl[] = {

	n_HTMLDocumentEvents_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,
	n_com_IDispatch_GetTypeInfoCount,
	n_com_IDispatch_GetTypeInfo,
	n_com_IDispatch_GetIDsOfNames,
	n_HTMLDocumentEvents_IDispatch_Invoke

};


HTMLDocumentEvents n_HTMLDocumentEvents_instance = { (void*) n_HTMLDocumentEvents_Vtbl };




#endif // _H_NONNON_WIN32_COM_HTMLDOCUMENTEVENTS

