// Nonnon General Types
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_TYPE
#define _H_NONNON_NEUTRAL_TYPE




#define s8           char
#define s16          short
#define s32          long
#define s64          long long

#define u8  unsigned char
#define u16 unsigned short
#define u32 unsigned long
#define u64 unsigned long long




// [Mechanism]
//
//	false is zero, true is non-zero
//	so you cannot use if ( var == true )
//
//	[ accurate code ]
//
//	if ( var ) { /* true */ }
//	if ( var != false ) { /*  true */ }
//	if ( var == false ) { /* false */ }


#if defined( _WINDOWS_H ) || defined( _MSC_VER )


// [!] : bool in _STDBOOL_H is incompatible with BOOL in Win32
// [!] : bool in C++ is incompatible with BOOL in Win32

#ifdef _STDBOOL_H

#undef bool
#undef false
#undef true

#endif // #ifdef _STDBOOL_H

#define bool  BOOL
#define false FALSE
#define true  TRUE


#else  // #if defined( _WINDOWS_H ) || defined( _MSC_VER )


#include <stdbool.h>


#endif // #if defined( _WINDOWS_H ) || defined( _MSC_VER )




#endif // _H_NONNON_NEUTRAL_TYPE

