// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_STDFONT
#define _H_NONNON_WIN32_WIN_STDFONT




#include "./_debug.c"
#include "./font.c"




HFONT
n_win_stdfont_hfont( void )
{

	// [Needed] : n_win_font_exit( hfont );


	// [!] : Compatibility : Vista : cb is different
	//
	//	currently not supported, but no problems

	const int cb = sizeof( NONCLIENTMETRICS );


	NONCLIENTMETRICS ncm; ZeroMemory( &ncm, cb );

	ncm.cbSize = cb;

	bool ret = SystemParametersInfo( SPI_GETNONCLIENTMETRICS, cb, &ncm, 0 );
	if ( ret == false ) { return NULL; }


	return n_win_font_logfont2hfont( &ncm.lfMessageFont );
}

void
n_win_stdfont_init( HWND *hgui, size_t count )
{

	// [Mechanism]
	//
	//	NONCLIENTMETRICS
	//	+ Explorer uses this setting
	//	+ Win95 accessibility color scheme
	//	+ Desktop Theme (including uxtheme)
	//
	//	DEFAULT_GUI_FONT
	//	+ dialog based applications use this font
	//	+ Win2000 or later : this can be replaced by DPI setting


	size_t i = 0;
	while( 1 )
	{

		HFONT hf = n_win_font_get( hgui[ i ] );
		n_win_font_exit( hf );

		hf = n_win_stdfont_hfont();
		n_win_font_set( hgui[ i ], hf, false );


		i++;
		if ( i >= count ) { break; }
	}


	return;
}

void
n_win_stdfont_exit( HWND *hgui, size_t count )
{

	size_t i = 0;
	while( 1 )
	{

		HFONT hf = n_win_font_get( hgui[ i ] );
		n_win_font_exit( hf );

		i++;
		if ( i >= count ) { break; }
	}


	return;
}


#endif // _H_NONNON_WIN32_WIN_STDFONT

