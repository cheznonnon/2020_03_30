// Watchcat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/neutral/string.c"

#include "../nonnon/win32/registry.c"




void
n_registry_uninstall2lnk( void )
{

	// DisplayIcon DisplayName UninstallString QuietUninstallString

	const n_posix_char *basekey = "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall";


	HKEY  hkey;
	LONG  ret;

	DWORD i, len;

	n_posix_char key[ N_PATH_MAX ];
	n_posix_char sub[ N_PATH_MAX ];
	n_posix_char lnk[ N_PATH_MAX ];
	n_posix_char exe[ N_PATH_MAX ];
	n_posix_char ico[ N_PATH_MAX ];


	ret = RegOpenKeyEx( HKEY_LOCAL_MACHINE, basekey, 0, KEY_ENUMERATE_SUB_KEYS, &hkey );
	if ( ret != ERROR_SUCCESS ) { return; }


	i = 0;
	while( 1 )
	{//break;

		len = N_PATH_MAX;
		ret = RegEnumKeyEx(hkey, i, key, &len, NULL, NULL,NULL,NULL);
		if ( ret != ERROR_SUCCESS ) { break; } else { i++; }
//n_posix_debug( key );


		n_posix_sprintf_literal( sub, "%s\\%s", basekey, key );

		len = N_PATH_MAX;
		n_string_zero( lnk, N_PATH_MAX );
		n_registry_read( HKEY_LOCAL_MACHINE, sub,     "DisplayName", lnk, len );

		len = N_PATH_MAX;
		n_string_zero( exe, N_PATH_MAX );
		n_registry_read( HKEY_LOCAL_MACHINE, sub, "UninstallString", exe, len );

		len = N_PATH_MAX;
		n_string_zero( ico, N_PATH_MAX );
		n_registry_read( HKEY_LOCAL_MACHINE, sub,     "DisplayIcon", ico, len );

if ( false == n_string_is_empty( exe ) ) { n_posix_debug( exe ); }

	}

	RegCloseKey( hkey );


	return;
}

