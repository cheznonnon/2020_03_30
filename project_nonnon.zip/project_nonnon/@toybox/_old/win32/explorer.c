// Nonnon Project Checker
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/neutral/string.c"

#include "../nonnon/win32/win/_debug.c"
#include "../nonnon/win32/win/gui.c"
#include "../nonnon/win32/sysinfo/version.c"




// internal
BOOL CALLBACK
n_explorer_EnumWindowsProc( HWND hwnd, LPARAM lParam )
{

	HWND *hwnd_ret = (void*) lParam;


	if (
		( n_win_class_is_same_literal( hwnd, "CabinetWClass" ) )
		&&
		( false == IsWindowVisible( hwnd ) )
	)
	{
//n_posix_debug( name );
/*
		HWND h = hwnd;

		h = n_win_hwnd_find_literal( h, "SHELLDLL_DefView" );
		h = n_win_hwnd_find_literal( h, "WorkerW"          );
		h = n_win_hwnd_find_literal( h, "ReBarWindow32"    );
		if ( h == NULL ) { return TRUE; }
*/

		(*hwnd_ret) = hwnd;


		return false;
	}


	return TRUE;
}

/*
void
n_explorer_winexec( const char *command, WORD showwindow )
{

	// PROCESS_INFORMATION is needed to execute

	STARTUPINFO         si;
	PROCESS_INFORMATION pi;


	ZeroMemory( &si, sizeof(STARTUPINFO        ) );
	ZeroMemory( &pi, sizeof(PROCESS_INFORMATION) );


	si.cb          = sizeof(STARTUPINFO);
	si.wShowWindow = showwindow;
	si.dwFlags     = STARTF_USESHOWWINDOW;


	// Check : this will be ignored

	//si.dwX      = 100;
	//si.dwY      = 200;
	//si.dwXSize  = 300;
	//si.dwYSize  = 300;
	//si.dwFlags  = STARTF_USEPOSITION | STARTF_USESIZE;


	CreateProcess(
		NULL,
		(void*) command,
		NULL,NULL,
		false,
		NORMAL_PRIORITY_CLASS,
		NULL,
		NULL,
		&si, &pi);


	WaitForInputIdle(pi.hProcess, INFINITE);


	CloseHandle(pi.hThread);
	CloseHandle(pi.hProcess);


	return;
}
*/

void
n_explorer_exec(const char *cmd, int from_or_to)
{

	// Problem : Win98 : crash
	//
	//	Win98's Explorer may use hidden "CabinetWClass"


	const int resizex = GetSystemMetrics( SM_CXSIZEFRAME );
	const int resizey = GetSystemMetrics( SM_CXSIZEFRAME );
	const int  maxwsx = GetSystemMetrics( SM_CXMAXIMIZED ) - ( resizex * 2 );
	const int  maxwsy = GetSystemMetrics( SM_CYMAXIMIZED ) - ( resizey * 2 );
	const int  halfsy = maxwsy / 2;


	HWND h;
	int  x,y,sx,sy;


	sx = maxwsx;
	sy = halfsy;

	sx = sx / 3 * 2;
	//sy = sy / 3 * 2;

	x  = ( maxwsx / 2 ) - ( sx / 2 );
	y  = ( halfsy / 2 ) - ( sy / 2 );

	if ( from_or_to ) { y += halfsy; }


	// Check : CreateProcess() + WaitForInputIdle()
	//
	//	the same result with WinExec()

	WinExec( cmd, SW_HIDE );
	//n_explorer_winexec(cmd, SW_HIDE);

	h = NULL;
	while( 1 )
	{

		// Problem : small value causes some troubles
		//
		//	Win98 : toolbar initialization error
		//	WinXP : window disappearing

		Sleep( 100 );

		EnumWindows( n_explorer_EnumWindowsProc, (LPARAM) &h );

		if ( h != NULL ) { break; }
	}


	// Check : WinXP : Sleep() is needed
	//
	//	MoveWindow() : position or size will not be set 
	//	ShowWindow() : SW_HIDE is called after SW_NORMAL

	Sleep( 100 );
	MoveWindow( h, x,y,sx,sy, TRUE );

	Sleep( 100 );
	ShowWindow( h, SW_NORMAL );


	// Check : view style change and toolbar
	//
	//	95 : OK
	//	98 : style change will be no effect
	//	2k : misbehave
	//	XP : misbehave : ListView_SetView(h, LV_VIEW_ICON); is needed

	if ( false == n_sysinfo_version_95 ) { return; }


	h = n_win_hwnd_find_literal( h, "SHELLDLL_DefView" );
	h = n_win_hwnd_find_literal( h, "SysListView32"    );


	// Check : Win95 : default is 16x16
	//
	//	#define LVS_ICON 0

	SetWindowLong( h, GWL_STYLE, GetWindowLong(h, GWL_STYLE) & ~LVS_TYPEMASK );


	return;
}

