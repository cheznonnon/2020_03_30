// Nekomimi Nina RPG
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_GAMECONSOLE

#include "../nonnon/project/define_unicode.c"

#endif // #ifdef N_GAMECONSOLE




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"

#include "../nonnon/game/chara.c"
#include "../nonnon/game/input.c"
#include "../nonnon/game/rc.c"
#include "../nonnon/game/sound.c"
#include "../nonnon/game/transition.c"


#include "../nonnon/neutral/wav/all.c"

#include "../nonnon/win32/gdi.c"


// [!] : MIDI trick support

#include "../nonnon/neutral/string_path.c"
#include "../nonnon/win32/resource.c"


#include "../nonnon/project/macro.c"




// Component

#include "./_personnel.c"




#define NNRPG_RC_WAV_0_00         "N_PROJECT_SOUND_GET"
#define NNRPG_RC_WAV_0_01         "N_PROJECT_SOUND_SH"
#define NNRPG_RC_WAV_0_02         "N_PROJECT_SOUND_BWOPP"
#define NNRPG_RC_WAV_1            "N_PROJECT_SOUND_PWAH"
#define NNRPG_RC_WAV_2            "N_PROJECT_SOUND_TING"
#define NNRPG_RC_WAV_FX_1         "N_PROJECT_SOUND_WOOW"

#define N_NNRPG_FRAME_MAX         3
#define N_NNRPG_FRAME_MSEC        50
#define N_NNRPG_FRAME_MSEC_EFFECT 50

#define N_NNRPG_SOUND_MAIN_BGM    &p->sound[ 0 ]
#define N_NNRPG_SOUND_TRANSITION  &p->sound[ 1 ]
#define N_NNRPG_SOUND_SIDH_FADING &p->sound[ 2 ]
#define N_NNRPG_SOUND_FANFARE     &p->sound[ 3 ]
#define N_NNRPG_SOUND_GAMEOVER    &p->sound[ 4 ]
#define N_NNRPG_SOUND_MAX                    5

#define N_NNRPG_PHASE_NONE        0
#define N_NNRPG_PHASE_INIT        1
#define N_NNRPG_PHASE_BATTLE      2
#define N_NNRPG_PHASE_FANFARE     3
#define N_NNRPG_PHASE_GAMEOVER    4

#define N_NNRPG_INPUT_INTERVAL    ( 333 )
#define N_NNRPG_INPUT_PHASE_NONE  ( 0 )
#define N_NNRPG_INPUT_PHASE_DONE  ( 1 )

#define N_NNRPG_END_PHASE_NONE    ( 0 )
#define N_NNRPG_END_PHASE_DONE    ( 1 )

#define N_NNRPG_PERSONNEL_NONE   -1
#define N_NNRPG_PERSONNEL_NINA    0
#define N_NNRPG_PERSONNEL_NONO    1
#define N_NNRPG_PERSONNEL_SIDH    2
#define N_NNRPG_PERSONNEL_MAX     3

#define N_NNRPG_REDRAW_NONE       ( 0 << 0 )
#define N_NNRPG_REDRAW_COMMAND    ( 1 << 0 )
#define N_NNRPG_REDRAW_MAINWIN    ( 1 << 1 )
#define N_NNRPG_REDRAW_CHARA      ( 1 << 2 )
#define N_NNRPG_REDRAW_ANIMATION  ( 1 << 3 )
#define N_NNRPG_REMAKE_MAINWIN    ( 1 << 4 )
#define N_NNRPG_REMAKE_ANIMATION  ( 1 << 5 )
#define N_NNRPG_DELETE_COMMAND    ( 1 << 6 )
#define N_NNRPG_DELETE_MAGIC      ( 1 << 7 )

#define N_NNRPG_COMBO_NONE        ( 0 << 0 )
#define N_NNRPG_COMBO_CHARA       ( 1 << 0 )
#define N_NNRPG_COMBO_EFFECT      ( 1 << 1 )

#define N_NNRPG_ANIMATION_NONE    0
#define N_NNRPG_ANIMATION_CHARA   1
#define N_NNRPG_ANIMATION_TIP     2
#define N_NNRPG_ANIMATION_DONE    3

#define N_NNRPG_STAR_MAX          7
#define N_NNRPG_KETTLE_MAX        9




typedef struct {

	int               phase;
	int               redraw;
	int               focus;
	int               target;
	int               command, command_focus;
	int               same;
	int               delayed_frame;

	n_bmp             bmp_bg;

	n_bmp             bmp_star  [ N_NNRPG_STAR_MAX   ];
	n_bmp             bmp_kettle[ N_NNRPG_KETTLE_MAX ];
	s32               magic_x, magic_y, magic_sx, magic_sy;

	n_nnrpg_personnel personnel[ N_NNRPG_PERSONNEL_MAX ];
	int               tip_start[ N_NNRPG_PERSONNEL_MAX ];
	n_nnrpg_window    window_main;
	n_nnrpg_window    window_text;

	n_game_sound      sound[ N_NNRPG_SOUND_MAX ];
	n_game_sound      sound_magic_fx[ N_NNRPG_PERSONNEL_MAX ];
	bool              midi_init;
	n_posix_char     *midi_tmpname;

	n_bmp             transition_bmp_old;
	n_bmp             transition_bmp_new;
	bool              transition_onoff;
	bool              screenshaker_onoff;

	n_game_input      input;
	int               input_phase;

	bool              is_game_over;
	bool              is_exhausted;

	bool              catsidh_action_onoff;

	bool              frame_reset;

} n_nnrpg;


#define n_nnrpg_zero( p ) n_memory_zero( p, sizeof( n_nnrpg ) )




static n_nnrpg nnrpg;




#define n_nnrpg_vibrate_off( p ) n_nnrpg_vibrate( p, false )
#define n_nnrpg_vibrate_on(  p ) n_nnrpg_vibrate( p,  true )

void
n_nnrpg_vibrate( n_nnrpg *p, bool is_on )
{

	int v;
	if ( is_on )
	{
		v = N_GAME_INPUT_XINPUT_VIBRATE_MAX;
	} else {
		v = 0;
	}

	n_game_input_XInput_vibrate( &p->input, v, v );


	return;
}

// internal
void
n_nnrpg_mainwindow( n_nnrpg *p, int p_count )
{

	int i   = 0;
	int cch = 0;
	while( 1 )
	{

		// [!] : CatSidh : exclude

		if ( i == ( p_count - 1 ) )
		{

			cch += n_posix_sprintf_literal
			(
				&p->window_text.msg[ cch ],
				"%s",
				N_STRING_SPACE
			);

		} else {

			cch += n_posix_sprintf_literal
			(
				&p->window_text.msg[ cch ],
				"%s%s   HP%3d%% MP%3d%% %s",
				N_STRING_SPACE,
				p->personnel[ i ].name,
				p->personnel[ i ].hp,
				p->personnel[ i ].mp,
				N_STRING_CRLF
			);

		}


		i++;
		if ( i >= p_count ) { break; }
	}


	n_nnrpg_window_bitmap_text( &p->window_text );


	return;
}

// internal
void
n_nnrpg_focus_arrange( n_nnrpg *p, int p_focus )
{

	if ( p_focus != p->focus )
	{
		p->same = 0;
		return;
	}


	p->same++;

	if ( p->same >= 2 )
	{

		p->same = 0;

		if ( p->focus == N_NNRPG_PERSONNEL_NINA )
		{
			if ( 0 == n_game_random( 2 ) )
			{
				if ( p->personnel[ N_NNRPG_PERSONNEL_NONO ].hp != 0 )
				{
					p->focus = N_NNRPG_PERSONNEL_NONO;
				} else {
					p->focus = N_NNRPG_PERSONNEL_SIDH;
				}
			} else {
				p->focus = N_NNRPG_PERSONNEL_SIDH;
			}
		} else
		if ( p->focus == N_NNRPG_PERSONNEL_NONO )
		{
			if ( 0 == n_game_random( 2 ) )
			{
				if ( p->personnel[ N_NNRPG_PERSONNEL_NINA ].hp != 0 )
				{
					p->focus = N_NNRPG_PERSONNEL_NINA;
				} else {
					p->focus = N_NNRPG_PERSONNEL_SIDH;
				}
			} else {
				p->focus = N_NNRPG_PERSONNEL_SIDH;
			}
		} else
		if ( p->focus == N_NNRPG_PERSONNEL_SIDH )
		{
			if ( 0 == n_game_random( 2 ) )
			{
				if ( p->personnel[ N_NNRPG_PERSONNEL_NINA ].hp != 0 )
				{
					p->focus = N_NNRPG_PERSONNEL_NINA;
				} else
				if ( p->personnel[ N_NNRPG_PERSONNEL_NONO ].hp != 0 )
				{
					p->focus = N_NNRPG_PERSONNEL_NONO;
				}
			} else {
				if ( p->personnel[ N_NNRPG_PERSONNEL_NONO ].hp != 0 )
				{
					p->focus = N_NNRPG_PERSONNEL_NONO;
				} else
				if ( p->personnel[ N_NNRPG_PERSONNEL_NINA ].hp != 0 )
				{
					p->focus = N_NNRPG_PERSONNEL_NINA;
				}
			}
		}

	}


	return;
}

// internal
void
n_nnrpg_frame_setter( n_nnrpg *p, int personnel )
{

	if ( p->personnel[ personnel ].hp == 0 )
	{

		if ( p->delayed_frame == 2 )
		{
			n_nnrpg_personnel_frame( &p->personnel[ personnel ], N_NNRPG_PERSONNEL_FRAME_EXHAUSTED, false );
		}

	} else
	if ( p->personnel[ personnel ].hp <= N_NNRPG_PERSONNEL_PINCH_THRESHOLD )
	{

		if ( ( p->command_focus == personnel )&&( p->command != N_NNRPG_COMMAND_NONE ) ) { return; }


		// [!] : CatSidh hasn't pinch + being hit

		if ( personnel != N_NNRPG_PERSONNEL_SIDH )
		{

			n_nnrpg_personnel_frame( &p->personnel[ personnel ], N_NNRPG_PERSONNEL_FRAME_PINCH, false );

		} else {

			if ( p->delayed_frame == 1 )
			{
				//
			} else
			if ( p->delayed_frame == 2 )
			{
				n_nnrpg_personnel_frame( &p->personnel[ personnel ], N_NNRPG_PERSONNEL_FRAME_EXHAUSTED, false );
			} else {
				n_nnrpg_personnel_frame( &p->personnel[ personnel ], N_NNRPG_PERSONNEL_FRAME_PINCH, false );
			}

		}

	}


	return;
}

// internal
void
n_nnrpg_redraw( n_nnrpg *p )
{

	const u32 msec_per_frame = N_NNRPG_FRAME_MSEC * N_NNRPG_FRAME_MAX;


	n_nnrpg_frame_setter( p, N_NNRPG_PERSONNEL_NINA );
	n_nnrpg_frame_setter( p, N_NNRPG_PERSONNEL_NONO );
	n_nnrpg_frame_setter( p, N_NNRPG_PERSONNEL_SIDH );


	static u32 timer_idling = 0;

	if ( p->redraw == N_NNRPG_REDRAW_NONE )
	{
//n_game_debug_count();
//return;

		if ( n_game_timer( &timer_idling, msec_per_frame ) )
		{
//n_game_debug_count();
//n_game_hwndprintf_literal( " %d %d ", p->focus, p->target );
//n_game_hwndprintf_literal( " %d ", p->personnel[ N_NNRPG_PERSONNEL_NINA ].chr.srcx );
//n_game_hwndprintf_literal( " %d ", p->personnel[ N_NNRPG_PERSONNEL_NINA ].frame );

			if ( p->target != N_NNRPG_PERSONNEL_NINA )
			{
				p->frame_reset = true;

				n_nnrpg_personnel_animation( &p->personnel[ N_NNRPG_PERSONNEL_NINA ], N_NNRPG_FRAME_MAX, true );
				n_game_refresh_on();
			}

			if ( p->target != N_NNRPG_PERSONNEL_NONO )
			{
				p->frame_reset = true;

				n_nnrpg_personnel_animation( &p->personnel[ N_NNRPG_PERSONNEL_NONO ], N_NNRPG_FRAME_MAX, true );
				n_game_refresh_on();
			}

			if ( p->target != N_NNRPG_PERSONNEL_SIDH )
			{
				//n_game_refresh_on();
			}

		}

//p->personnel[ N_NNRPG_PERSONNEL_SIDH ].chr.x = n_nnrpg_metric.chara_2_x + ( -1 + n_game_random( 2 ) );
//p->personnel[ N_NNRPG_PERSONNEL_SIDH ].chr.y = n_nnrpg_metric.chara_2_y + ( -1 + n_game_random( 2 ) );


		if ( n_game_refresh_is_on() )
		{
			n_nnrpg_personnel_erase( &p->personnel[ N_NNRPG_PERSONNEL_NINA ] );
			n_nnrpg_personnel_erase( &p->personnel[ N_NNRPG_PERSONNEL_NONO ] );
			if ( p->personnel[ N_NNRPG_PERSONNEL_SIDH ].hp != 0 )
			{
				n_nnrpg_personnel_erase( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ] );
			}

			n_nnrpg_personnel_draw( &p->personnel[ N_NNRPG_PERSONNEL_NINA ], true );
			n_nnrpg_personnel_draw( &p->personnel[ N_NNRPG_PERSONNEL_NONO ], true );
			if ( p->personnel[ N_NNRPG_PERSONNEL_SIDH ].hp != 0 )
			{
				n_nnrpg_personnel_draw( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ], true );
			}
		}


		return;
	}

	if ( p->frame_reset )
	{
		p->frame_reset = false;

		p->personnel[ N_NNRPG_PERSONNEL_NINA ].chr.srcy = 0;
		p->personnel[ N_NNRPG_PERSONNEL_NONO ].chr.srcy = 0;

		p->personnel[ N_NNRPG_PERSONNEL_NINA ].frame = 0;
		p->personnel[ N_NNRPG_PERSONNEL_NONO ].frame = 0;
	}


	// Benchmarker

	bool debug_benchmark_onoff = false;//true;

	u32 tick_before = n_posix_tickcount();


	// Erase

	if ( p->redraw & N_NNRPG_DELETE_MAGIC )
	{

		n_bmp_fastcopy
		(
			n_nnrpg_metric.bg,
			n_nnrpg_metric.canvas,
			p->magic_x,p->magic_y,p->magic_sx,p->magic_sy,
			p->magic_x,p->magic_y
		);

		p->redraw &= ~N_NNRPG_DELETE_MAGIC;
		p->redraw |=  N_NNRPG_REDRAW_CHARA;

	}

	if ( p->redraw & N_NNRPG_REDRAW_MAINWIN )
	{

		n_nnrpg_window_erase( &p->window_text );

	}

	if ( ( p->redraw & N_NNRPG_REDRAW_COMMAND )||( p->redraw & N_NNRPG_DELETE_COMMAND ) )
	{

		if ( p->focus != N_NNRPG_PERSONNEL_SIDH )
		{
			n_nnrpg_personnel_command_erase( &p->personnel[ p->focus ] );
		}

	}

	if ( p->redraw & ( N_NNRPG_REDRAW_CHARA | N_NNRPG_REDRAW_ANIMATION ) )
	{

		n_nnrpg_personnel_erase( &p->personnel[ N_NNRPG_PERSONNEL_NINA ] );
		n_nnrpg_personnel_erase( &p->personnel[ N_NNRPG_PERSONNEL_NONO ] );
		n_nnrpg_personnel_erase( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ] );

	}


	// Remake

	if ( p->redraw & N_NNRPG_REMAKE_MAINWIN )
	{

		n_nnrpg_mainwindow( p, N_NNRPG_PERSONNEL_MAX );

	}


	if ( ( p->redraw & N_NNRPG_REMAKE_ANIMATION )&&( p->input_phase != N_NNRPG_INPUT_PHASE_NONE ) )
	{
//n_game_debug_count();

		p->input_phase = N_NNRPG_INPUT_PHASE_NONE;

		p->command       = n_nnrpg_personnel_command_get( &p->personnel[ p->focus ] );
		p->command_focus = p->focus;
//p->command = N_NNRPG_COMMAND_MAGIC;
//p->command = N_NNRPG_COMMAND_HEAL;

		if ( p->command == N_NNRPG_COMMAND_ATTACK )
		{
			p->screenshaker_onoff = n_nnrpg_personnel_attack( &p->personnel[ p->focus ], &p->personnel[ p->target ] );
			if ( p->screenshaker_onoff ) { p->delayed_frame = 1; }
		} else
		if ( p->command == N_NNRPG_COMMAND_MAGIC  )
		{
			p->screenshaker_onoff = n_nnrpg_personnel_magic ( &p->personnel[ p->focus ], &p->personnel[ p->target ] );
			if ( p->screenshaker_onoff ) { p->delayed_frame = 1; }
		} else
		if ( p->command == N_NNRPG_COMMAND_HEAL   )
		{
			n_nnrpg_personnel_heal( &p->personnel[ p->focus ] );
		}

	}


	// Draw

	if ( p->redraw & N_NNRPG_REDRAW_MAINWIN )
	{

		n_nnrpg_window_draw( &p->window_main );
		n_nnrpg_window_draw( &p->window_text );

		if ( ( p->focus != N_NNRPG_PERSONNEL_NONE )&&( p->focus != N_NNRPG_PERSONNEL_SIDH ) )
		{
			n_nnrpg_window_focus( &p->window_text, p->focus, N_NNRPG_PERSONNEL_MAX );
		}

	}

	if ( p->redraw & N_NNRPG_REDRAW_COMMAND )
	{

		if ( p->focus != N_NNRPG_PERSONNEL_SIDH )
		{
			n_nnrpg_personnel_command_draw( &p->personnel[ p->focus ] );
		}

	}

	static bool effect = false;

	if ( p->redraw & ( N_NNRPG_REDRAW_CHARA | N_NNRPG_REDRAW_ANIMATION ) )
	{
//n_game_hwndprintf_literal( " %d %d ", p->focus, p->target );

		if ( ( p->focus == N_NNRPG_PERSONNEL_SIDH )&&( p->command != N_NNRPG_COMMAND_HEAL ) )
		{
//n_game_debug_count();
			n_nnrpg_personnel_draw_main( &p->personnel[ N_NNRPG_PERSONNEL_NINA ], ( p->target == N_NNRPG_PERSONNEL_NINA ), true, effect );
			n_nnrpg_personnel_draw_main( &p->personnel[ N_NNRPG_PERSONNEL_NONO ], ( p->target == N_NNRPG_PERSONNEL_NONO ), true, effect );
			n_nnrpg_personnel_draw_main( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ], ( p->focus  == N_NNRPG_PERSONNEL_SIDH ), true,   true );
		} else {
			n_nnrpg_personnel_draw_main( &p->personnel[ N_NNRPG_PERSONNEL_NINA ], true, true, effect );
			n_nnrpg_personnel_draw_main( &p->personnel[ N_NNRPG_PERSONNEL_NONO ], true, true, effect );
			n_nnrpg_personnel_draw_main( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ], true, true, effect );
		}

	}

	if ( p->redraw & N_NNRPG_REDRAW_ANIMATION )
	{

		static u32    timer = 0;
		static u32    phase = N_NNRPG_ANIMATION_NONE;
		static int    combo = N_NNRPG_COMBO_NONE;
		static int    frame = 0;

		static double dstep = 0;
		static double istep = 0;
		static double ostep = 0;

		static s32    magic = 0;
		static s32    xstep = 0;
		static s32    ystep = 0;
		static u32    tmr_2 = 0;

		if ( timer == 0 )
		{

			n_game_timer( &timer, 0 );

			frame = 0;
			tmr_2 = 0;
			magic = 0;

			if ( phase == N_NNRPG_ANIMATION_NONE )
			{

				p->personnel[ N_NNRPG_PERSONNEL_NINA ].frame = 0;
				p->personnel[ N_NNRPG_PERSONNEL_NONO ].frame = 0;
				p->personnel[ N_NNRPG_PERSONNEL_SIDH ].frame = 0;

				p->tip_start[ N_NNRPG_PERSONNEL_NINA ] = p->personnel[ N_NNRPG_PERSONNEL_NINA ].tip.y;
				p->tip_start[ N_NNRPG_PERSONNEL_NONO ] = p->personnel[ N_NNRPG_PERSONNEL_NONO ].tip.y;
				p->tip_start[ N_NNRPG_PERSONNEL_SIDH ] = p->personnel[ N_NNRPG_PERSONNEL_SIDH ].tip.y;

				combo = N_NNRPG_COMBO_NONE;

				dstep = istep = ostep = 0;

				if ( p->focus == N_NNRPG_PERSONNEL_NONO ) { n_nnrpg_personnel_sound( &p->personnel[ N_NNRPG_PERSONNEL_NONO ] ); }
				if ( p->focus == N_NNRPG_PERSONNEL_SIDH ) { n_nnrpg_personnel_sound( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ] ); }

			} else
			if ( phase == N_NNRPG_ANIMATION_CHARA )
			{

				//

			} else
			if ( phase == N_NNRPG_ANIMATION_TIP )
			{

				p->delayed_frame = 2;

				p->personnel[ N_NNRPG_PERSONNEL_NINA ].frame = 0;
				p->personnel[ N_NNRPG_PERSONNEL_NONO ].frame = 0;
				p->personnel[ N_NNRPG_PERSONNEL_SIDH ].frame = 0;

				if ( p->target != N_NNRPG_PERSONNEL_NONE )
				{
					if ( p->personnel[ p->target ].hp == 0 )
					{
						p->is_exhausted = true;
					}

					effect = true;
				}

				p->personnel[ N_NNRPG_PERSONNEL_NINA ].tip_color = p->personnel[ N_NNRPG_PERSONNEL_NINA ].tip_color_delayed;
				p->personnel[ N_NNRPG_PERSONNEL_NONO ].tip_color = p->personnel[ N_NNRPG_PERSONNEL_NONO ].tip_color_delayed;
				p->personnel[ N_NNRPG_PERSONNEL_SIDH ].tip_color = p->personnel[ N_NNRPG_PERSONNEL_SIDH ].tip_color_delayed;

			}

		}


//n_game_hwndprintf_literal( " Phase %d ", phase );

		if ( ( phase == N_NNRPG_ANIMATION_NONE )||( phase == N_NNRPG_ANIMATION_CHARA ) )
		{

			if ( n_game_timer( &timer, msec_per_frame ) )
			{
//n_game_hwndprintf_literal( " %d %d %d %d ", p->focus, p->target, phase, p->personnel[ N_NNRPG_PERSONNEL_NINA ].frame );

				n_nnrpg_personnel_animation( &p->personnel[ N_NNRPG_PERSONNEL_NINA ], N_NNRPG_FRAME_MAX, ( p->focus != N_NNRPG_PERSONNEL_NINA ) );
				n_nnrpg_personnel_animation( &p->personnel[ N_NNRPG_PERSONNEL_NONO ], N_NNRPG_FRAME_MAX, ( p->focus != N_NNRPG_PERSONNEL_NONO ) );

				frame++;

				if ( p->focus == N_NNRPG_PERSONNEL_NINA )
				{
					if ( ( p->command == N_NNRPG_COMMAND_ATTACK )&&( frame == 1 ) )
					{
						n_nnrpg_personnel_sound( &p->personnel[ N_NNRPG_PERSONNEL_NINA ] );
						if ( p->personnel[ N_NNRPG_PERSONNEL_SIDH ].hp <= N_NNRPG_PERSONNEL_PINCH_THRESHOLD )
						{
							n_nnrpg_personnel_frame( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ], N_NNRPG_PERSONNEL_FRAME_EXHAUSTED, true );
						} else {
							n_nnrpg_personnel_frame( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ], N_NNRPG_PERSONNEL_FRAME_HIT      , true );
						}
						n_nnrpg_personnel_animation( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ], 1, false );
					}
				}

				if ( frame >= ( N_NNRPG_FRAME_MAX - 1 ) )
				{
					combo |= N_NNRPG_COMBO_CHARA;
				}

			} else {

				p->redraw = N_NNRPG_REDRAW_CHARA | N_NNRPG_REDRAW_ANIMATION;

			}


			if ( p->target == N_NNRPG_PERSONNEL_SIDH )
			{

				if ( p->focus == N_NNRPG_PERSONNEL_NINA )
				{

					if ( p->command == N_NNRPG_COMMAND_ATTACK )
					{

						if ( frame >= 1 )
						{

							n_bmp *b_f = &p->personnel[ N_NNRPG_PERSONNEL_NINA ].bmp_attack;
							n_bmp *b_t = &p->bmp_star[ (int) trunc( istep ) ];

							s32 x,y,sx,sy; n_nnrpg_personnel_rectangle_get( &p->personnel[ p->target ], &x, &y, &sx, &sy );

							x += N_BMP_SX( b_f ) - ( N_BMP_SX( b_t ) / 2 ) - ( N_BMP_SX( b_f ) / 4 );
							y -= N_BMP_SY( b_f ) - ( N_BMP_SY( b_t ) / 2 ) - ( N_BMP_SY( b_f ) / 4 );

							// [!] : zero for rotate test
							//s32 offset = 0;
							s32 offset = ostep * n_nnrpg_metric.zoom;

							x += offset;
							y -= offset;

							n_bmp b; n_bmp_carboncopy( b_t, &b );
							n_bmp_resampler( &b, ostep / 10, ostep / 10 );

							s32 u = n_nnrpg_metric.unit_bmp;
							n_bmp_resizer( &b, u,u, n_bmp_white_invisible, N_BMP_RESIZER_CENTER );

							n_bmp_transcopy
							(
								&b,
								&game.bmp,
								0,0,N_BMP_SX( &b ),N_BMP_SY( &b ),
								x,y
							);

							n_bmp_free_fast( &b );

							ostep += 1.5;
							if ( ostep >= 10 )
							{
								ostep = 10;

								if ( tmr_2 == 0 ) { n_game_timer( &tmr_2, 0 ); }

								if ( n_game_timer( &tmr_2, N_NNRPG_FRAME_MSEC_EFFECT * 10 ) )
								{
									combo |= N_NNRPG_COMBO_EFFECT;
								}
							}

							istep += 0.33;
							if ( istep >=  7 ) { istep =  0; }


							p->redraw |= N_NNRPG_DELETE_MAGIC;

							p->magic_x  = x;
							p->magic_y  = y;
							p->magic_sx = sx;
							p->magic_sy = sy;

						}

					} else
					if (
						( p->command == N_NNRPG_COMMAND_MAGIC )
						&&
						( p->screenshaker_onoff )
					)
					{

						static int magic_phase;
						static s32 tx,ty;
						static s32 rotate;
						static u32 rotate_timer;

						if ( magic == 0 )
						{
							magic       = 1;
							magic_phase = 0;

							n_game_timer( &tmr_2, 0 );

							n_nnrpg_personnel_rectangle_get( &p->personnel[ p->target ], &tx, &ty, NULL, NULL );

							ystep = n_posix_max( 1, ty / N_NNRPG_FRAME_MSEC_EFFECT ) * 3;

							rotate = n_game_random( N_NNRPG_KETTLE_MAX );
							n_game_timer( &rotate_timer, 0 );
						}


						s32 x = tx;
						s32 y =  0;

						if ( magic_phase == 0 )
						{

							if ( n_game_timer( &tmr_2, N_NNRPG_FRAME_MSEC_EFFECT * 8 ) )
							{
								magic_phase = 1;
							}

							if ( n_game_timer( &rotate_timer, N_NNRPG_FRAME_MSEC_EFFECT / 2 ) )
							{
								rotate++;
								if ( rotate >= N_NNRPG_KETTLE_MAX ) { rotate = 0; }
							}

						} else
						if ( magic_phase == 1 )
						{

							y = ( ystep * magic );
							if ( y > ty ) { y = ty; }

							if ( y == ty )
							{
								if ( false == ( combo & N_NNRPG_COMBO_EFFECT ) )
								{
									n_game_sound_loop( &p->sound_magic_fx[ N_NNRPG_PERSONNEL_NINA ] );
								}

								combo |= N_NNRPG_COMBO_EFFECT;
							}

							magic++;

						}

						s32 m = n_nnrpg_metric.unit_pad;
						s32 u = n_nnrpg_metric.unit_bmp;
						n_bmp_transcopy
						(
							&p->bmp_kettle[ rotate ],
							&game.bmp,
							m,m,u-(m*2),u-(m*2),
							x+m,y+m
						);


						p->redraw |= N_NNRPG_DELETE_MAGIC;

						p->magic_x  = x;
						p->magic_y  = y;
						p->magic_sx = n_nnrpg_metric.unit_bmp;
						p->magic_sy = n_nnrpg_metric.unit_bmp;

					} else {

						combo |= N_NNRPG_COMBO_EFFECT;

					}

				} else
				if ( p->focus == N_NNRPG_PERSONNEL_NONO )
				{

					if ( p->command == N_NNRPG_COMMAND_ATTACK )
					{

						s32 x,y; n_nnrpg_personnel_rectangle_get( &p->personnel[ p->target ], &x, &y, NULL, NULL );

						n_bmp_transcopy
						(
							&p->personnel[ N_NNRPG_PERSONNEL_NONO ].bmp_attack,
							&game.bmp,
							0,0,n_nnrpg_metric.unit_bmp,istep,
							x,y
						);

						istep += N_NNRPG_FRAME_MSEC_EFFECT / 10;
						if ( istep >= n_nnrpg_metric.unit_bmp )
						{
							combo |= N_NNRPG_COMBO_EFFECT;
						}

					} else
					if (
						( p->command == N_NNRPG_COMMAND_MAGIC )
						&&
						( p->screenshaker_onoff )
					)
					{

						static s32 fx,fy,tx,ty;

						if ( magic == 0 )
						{
							n_nnrpg_personnel_rectangle_get( &p->personnel[ p->focus  ], &fx, &fy, NULL, NULL );
							n_nnrpg_personnel_rectangle_get( &p->personnel[ p->target ], &tx, &ty, NULL, NULL );

							xstep = n_posix_max( 1, ( fx - tx ) / N_NNRPG_FRAME_MSEC_EFFECT * 2 );
							ystep = n_posix_max( 1, ( fy - ty ) / N_NNRPG_FRAME_MSEC_EFFECT * 2 );
						}

						s32 x = fx - ( xstep * magic );
						s32 y = fy - ( ystep * magic );

						if ( x < tx ) { x = tx; }
						if ( y < ty ) { y = ty; }
//n_game_hwndprintf_literal( " %d %d : %d %d : %d %d ", x, tx, y, ty, xstep, ystep );

						if ( x == tx )//( ( x == tx )&&( y == ty ) )
						{
							if ( false == ( combo & N_NNRPG_COMBO_EFFECT ) )
							{
								n_game_sound_loop( &p->sound_magic_fx[ N_NNRPG_PERSONNEL_NONO ] );
							}

							combo |= N_NNRPG_COMBO_EFFECT;
						}

						s32 m = n_nnrpg_metric.unit_pad;
						s32 u = n_nnrpg_metric.unit_bmp;
						n_bmp_transcopy
						(
							&p->personnel[ N_NNRPG_PERSONNEL_NONO ].bmp_magic,
							&game.bmp,
							    m,     m, u - ( m * 2 ), u - ( m * 2 ),
							x + m, y + m
						);

						if ( n_game_timer( &tmr_2, N_NNRPG_FRAME_MSEC_EFFECT / 4 ) )
						{
							magic++;
						}


						p->redraw |= N_NNRPG_DELETE_MAGIC;

						p->magic_x  = x;
						p->magic_y  = y;
						p->magic_sx = n_nnrpg_metric.unit_bmp;
						p->magic_sy = n_nnrpg_metric.unit_bmp;

					} else {

						combo |= N_NNRPG_COMBO_EFFECT;

					}

				} else {

					combo |= N_NNRPG_COMBO_EFFECT;

				}

			} else {

				combo |= N_NNRPG_COMBO_EFFECT;

			}

			if ( combo == ( N_NNRPG_COMBO_CHARA | N_NNRPG_COMBO_EFFECT ) )
			{
				timer = 0;
				phase = N_NNRPG_ANIMATION_TIP;
			}

		} else
		if ( phase == N_NNRPG_ANIMATION_TIP )
		{

			if (
				( p->screenshaker_onoff )
				&&
				( p->target != N_NNRPG_PERSONNEL_NONE )
			)
			{
				n_nnrpg_personnel_frame( &p->personnel[ p->target ], N_NNRPG_PERSONNEL_FRAME_HIT, false );
			}


			if ( p->focus == N_NNRPG_PERSONNEL_NONO )
			{
				if ( n_game_timer( &timer_idling, msec_per_frame ) )
				{
					n_nnrpg_personnel_animation( &p->personnel[ N_NNRPG_PERSONNEL_NINA ], N_NNRPG_FRAME_MAX, true );
				}
			} else
			if ( p->focus == N_NNRPG_PERSONNEL_NINA )
			{
				if ( n_game_timer( &timer_idling, msec_per_frame ) )
				{
					n_nnrpg_personnel_animation( &p->personnel[ N_NNRPG_PERSONNEL_NONO ], N_NNRPG_FRAME_MAX, true );
				}
			} else
			if ( p->focus == N_NNRPG_PERSONNEL_SIDH )
			{
				if ( n_game_timer( &timer_idling, msec_per_frame ) )
				{
					n_nnrpg_personnel_animation( &p->personnel[ N_NNRPG_PERSONNEL_NINA ], N_NNRPG_FRAME_MAX, true );
					n_nnrpg_personnel_animation( &p->personnel[ N_NNRPG_PERSONNEL_NONO ], N_NNRPG_FRAME_MAX, true );
				}
			}


			s32 ty_nina = p->tip_start[ N_NNRPG_PERSONNEL_NINA ];
			s32 ty_nono = p->tip_start[ N_NNRPG_PERSONNEL_NONO ];
			s32 ty_sidh = p->tip_start[ N_NNRPG_PERSONNEL_SIDH ];

			// [!] : tips : large value for "anim" to debug "jump"

			double jump = 1 + ( dstep / 0.5 );
			double anim = ( n_nnrpg_metric.unit_bmp / 4 );
			double move = ( anim / jump ) * fabs( sin( 2 * M_PI * dstep ) );

			p->personnel[ N_NNRPG_PERSONNEL_NINA ].tip.y = ty_nina - move;
			p->personnel[ N_NNRPG_PERSONNEL_NONO ].tip.y = ty_nono - move;
			p->personnel[ N_NNRPG_PERSONNEL_SIDH ].tip.y = ty_sidh - move;

			if ( n_game_timer( &tmr_2, N_NNRPG_FRAME_MSEC_EFFECT / 4 ) )
			{
				dstep += 0.020;
				if ( dstep >= 1.0 ) { timer = 0; phase = N_NNRPG_ANIMATION_DONE; }
//n_game_hwndprintf_literal( " %g ", dstep );
			}

			n_nnrpg_personnel_draw_tip( &p->personnel[ N_NNRPG_PERSONNEL_NINA ] );
			n_nnrpg_personnel_draw_tip( &p->personnel[ N_NNRPG_PERSONNEL_NONO ] );
			n_nnrpg_personnel_draw_tip( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ] );

		} else
		if ( phase == N_NNRPG_ANIMATION_DONE )
		{

			phase = N_NNRPG_ANIMATION_NONE;

			// [Needed] : magic is shared
			timer = magic = 0;

			p->redraw = N_NNRPG_REMAKE_MAINWIN | N_NNRPG_REDRAW_MAINWIN | N_NNRPG_REDRAW_CHARA;

			n_nnrpg_personnel_neutral( &p->personnel[ N_NNRPG_PERSONNEL_NINA ], true );
			n_nnrpg_personnel_neutral( &p->personnel[ N_NNRPG_PERSONNEL_NONO ], true );
			n_nnrpg_personnel_neutral( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ], true );

			p->focus = p->target = N_NNRPG_PERSONNEL_NONE;


		}


		if ( p->screenshaker_onoff )
		{
			n_game_screenshaker( 4 );
			if ( p->focus == N_NNRPG_PERSONNEL_SIDH ) { n_nnrpg_vibrate_on( p ); }
		}

	} else {

		p->command       = N_NNRPG_COMMAND_NONE;
		p->command_focus = N_NNRPG_PERSONNEL_NONE;


		p->screenshaker_onoff = false;
		n_game_screenshaker( 0 );
		n_nnrpg_vibrate_off( p );


		n_nnrpg_personnel_tip_exit( &p->personnel[ N_NNRPG_PERSONNEL_NINA ] );
		n_nnrpg_personnel_tip_exit( &p->personnel[ N_NNRPG_PERSONNEL_NONO ] );
		n_nnrpg_personnel_tip_exit( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ] );


		p->delayed_frame = 0;


		p->catsidh_action_onoff = false;


		p->redraw = N_NNRPG_REDRAW_NONE;


		if ( debug_benchmark_onoff )
		{
			n_game_hwndprintf_literal( " %d ", (int) n_posix_tickcount() - tick_before );
		}

	}


	n_game_refresh_on();
	return;
}

// internal
void
n_nnrpg_input( n_nnrpg *p )
{
//n_game_hwndprintf_literal( " %d ", p->focus );


	const u32 interval_wait = 1000;


	if ( p->focus == N_NNRPG_PERSONNEL_NONE )
	{

		if ( p->input_phase != N_NNRPG_INPUT_PHASE_NONE ) { return; }


		n_nnrpg_personnel_bulk_wait( p->personnel, N_NNRPG_PERSONNEL_MAX );
//n_game_hwndprintf_literal( "%d %d %d", p->personnel[ 0 ].wait, p->personnel[ 1 ].wait, p->personnel[ 2 ].wait );

		static u32 wait_timer = 0;

		if ( wait_timer == 0 )
		{

			n_game_timer( &wait_timer, 0 );

		} else
		if ( n_game_timer( &wait_timer, interval_wait ) )
		{

			static int p_focus = N_NNRPG_PERSONNEL_NONE;

			while( 1 )
			{

				p->focus = n_nnrpg_personnel_bulk_wait_focus( p->personnel, N_NNRPG_PERSONNEL_MAX );
				n_nnrpg_personnel_bulk_wait_reset( p->personnel, N_NNRPG_PERSONNEL_MAX );

				if ( p->focus != N_NNRPG_PERSONNEL_NONE ) { break; }

			}

if ( n_game_input_loop( &p->input, '1' ) ) { p->focus = N_NNRPG_PERSONNEL_NINA; }
if ( n_game_input_loop( &p->input, '2' ) ) { p->focus = N_NNRPG_PERSONNEL_NONO; }
if ( n_game_input_loop( &p->input, '3' ) ) { p->focus = N_NNRPG_PERSONNEL_SIDH; }

			n_nnrpg_focus_arrange( p, p_focus );

//n_game_hwndprintf_literal( " Prv %d : Cur %d : Same %d ", p_focus, p->focus, p->same );

			p_focus = p->focus;


			wait_timer = 0;

			p->redraw |= N_NNRPG_REMAKE_MAINWIN | N_NNRPG_REDRAW_MAINWIN;
			p->redraw |= N_NNRPG_REDRAW_COMMAND;

			p->input_phase = N_NNRPG_INPUT_PHASE_DONE;

		}

	} else
	if ( p->focus != N_NNRPG_PERSONNEL_SIDH )
	{
//focus = N_NNRPG_PERSONNEL_NONE; input_phase = N_NNRPG_INPUT_PHASE_NONE; return;

		if ( p->input_phase != N_NNRPG_INPUT_PHASE_DONE ) { return; }


		static u32 timer_up = 0;
		if ( timer_up == 0 ) { timer_up = n_posix_tickcount(); }

		static u32 timer_dw = 0;
		if ( timer_dw == 0 ) { timer_dw = n_posix_tickcount(); }

		if ( n_game_input_loop( &p->input, VK_UP ) )
		{

			timer_dw = 0;

			if ( n_game_timer( &timer_up, N_NNRPG_INPUT_INTERVAL ) )
			{
				n_nnrpg_personnel_command_up( &p->personnel[ p->focus ] );
				p->redraw |= N_NNRPG_REDRAW_COMMAND;
			}

		} else
		if ( n_game_input_loop( &p->input, VK_DOWN ) )
		{

			timer_up = 0;

			if ( n_game_timer( &timer_dw, N_NNRPG_INPUT_INTERVAL ) )
			{
				n_nnrpg_personnel_command_down( &p->personnel[ p->focus ] );
				p->redraw |= N_NNRPG_REDRAW_COMMAND;
			}

		} else
		if ( n_game_input_loop( &p->input, VK_SPACE ) )
		{
//n_game_debug_count();

			timer_up = 0;
			timer_dw = 0;

			if ( false == ( p->redraw & N_NNRPG_REDRAW_COMMAND ) )
			{

				p->target = N_NNRPG_PERSONNEL_SIDH;

				n_posix_sleep( 200 );

				p->redraw |= N_NNRPG_REMAKE_MAINWIN | N_NNRPG_REDRAW_MAINWIN;
				p->redraw |= N_NNRPG_REDRAW_CHARA;
				p->redraw |= N_NNRPG_REMAKE_ANIMATION | N_NNRPG_REDRAW_ANIMATION;
				p->redraw |= N_NNRPG_DELETE_COMMAND;

			}

		}// else

	} else
	if ( p->focus == N_NNRPG_PERSONNEL_SIDH )
	{
//p->focus = N_NNRPG_PERSONNEL_NONE; p->input_phase = N_NNRPG_INPUT_PHASE_NONE; return;

		if ( p->catsidh_action_onoff ) { return; }
//n_game_debug_count();

		p->catsidh_action_onoff = true;


		// [!] : AI

		bool is_heal = false;

		n_nnrpg_personnel_command_set( &p->personnel[ p->focus ], N_NNRPG_COMMAND_ATTACK );

		if ( p->personnel[ p->focus ].mp != 0 )
		{
			if ( p->personnel[ p->focus ].hp < 30 )
			{
				is_heal = true;
				n_nnrpg_personnel_command_set( &p->personnel[ p->focus ], N_NNRPG_COMMAND_HEAL );
			} else
			if ( 0 == n_game_random( 10 ) )
			{
				n_nnrpg_personnel_command_set( &p->personnel[ p->focus ], N_NNRPG_COMMAND_MAGIC );
			}
		}

		if ( is_heal )
		{
			p->target = N_NNRPG_PERSONNEL_NONE;
		} else {
			if ( p->personnel[ N_NNRPG_PERSONNEL_NINA ].hp > p->personnel[ N_NNRPG_PERSONNEL_NONO ].hp )
			{
				p->target = N_NNRPG_PERSONNEL_NINA;
			} else
			if ( p->personnel[ N_NNRPG_PERSONNEL_NONO ].hp > p->personnel[ N_NNRPG_PERSONNEL_NINA ].hp )
			{
				p->target = N_NNRPG_PERSONNEL_NONO;
			} else {
				p->target = n_game_random( 2 );
			}
		}

		p->redraw |= N_NNRPG_REMAKE_MAINWIN | N_NNRPG_REDRAW_MAINWIN;
		p->redraw |= N_NNRPG_REDRAW_CHARA;
		p->redraw |= N_NNRPG_REMAKE_ANIMATION | N_NNRPG_REDRAW_ANIMATION;

	}


	return;
}

// internal
void
n_nnrpg_reset( n_nnrpg *p )
{

	if ( p->redraw != N_NNRPG_REDRAW_NONE ) { return; }


	n_nnrpg_personnel_neutral( &p->personnel[ N_NNRPG_PERSONNEL_NINA ], true );
	n_nnrpg_personnel_neutral( &p->personnel[ N_NNRPG_PERSONNEL_NONO ], true );
	n_nnrpg_personnel_neutral( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ], true );

	int debug = 1;
	p->personnel[ N_NNRPG_PERSONNEL_NINA ].hp = p->personnel[ N_NNRPG_PERSONNEL_NINA ].mp = 100 / debug;
	p->personnel[ N_NNRPG_PERSONNEL_NONO ].hp = p->personnel[ N_NNRPG_PERSONNEL_NONO ].mp = 100 / debug;
	p->personnel[ N_NNRPG_PERSONNEL_SIDH ].hp = p->personnel[ N_NNRPG_PERSONNEL_SIDH ].mp = 100 / debug;
//p->personnel[ N_NNRPG_PERSONNEL_NINA ].mp = 0;
//p->personnel[ N_NNRPG_PERSONNEL_NONO ].mp = 0;
//p->personnel[ N_NNRPG_PERSONNEL_SIDH ].mp = 0;


	p->phase  = N_NNRPG_PHASE_INIT;

	p->redraw  = N_NNRPG_REDRAW_CHARA;
	p->redraw |= N_NNRPG_REMAKE_MAINWIN | N_NNRPG_REDRAW_MAINWIN;


	p->focus  = N_NNRPG_PERSONNEL_NONE;
	p->target = N_NNRPG_PERSONNEL_NONE;


	p->is_exhausted = false;
	p->is_game_over = false;


	p->input_phase = N_NNRPG_INPUT_PHASE_NONE;


	return;
}




void
n_nnrpg_init( n_nnrpg *p )
{

	// System

	n_bmp_safemode = false;


	n_nnrpg_metric_make( &p->bmp_bg, &game.bmp );


	n_game_title_literal( "+++Nekomimi Nina RPG+++" );

	game.sx    = n_nnrpg_metric.csx;
	game.sy    = n_nnrpg_metric.csy;
	game.fps   = 60;
	game.color = n_bmp_black;

	n_win_set_patch( game.hwnd, &game.sx, &game.sy, 16, 16 );

	n_game_window_fixed();


	// Init

	n_game_sound_bulk_zero( p->sound, N_NNRPG_SOUND_MAX );

	n_game_sound_init_literal( N_NNRPG_SOUND_TRANSITION , game.hwnd, "NNRPG_RC_WAV_INIT" );
	n_game_sound_init_literal( N_NNRPG_SOUND_SIDH_FADING, game.hwnd, "NNRPG_RC_WAV_FADE" );
	n_game_sound_init_literal( N_NNRPG_SOUND_FANFARE    , game.hwnd, "NNRPG_RC_WAV_FNFR" );
	n_game_sound_init_literal( N_NNRPG_SOUND_GAMEOVER   , game.hwnd, "NNRPG_RC_WAV_OVER" );

	n_wav_smoother( N_NNRPG_SOUND_TRANSITION .wav );
	n_wav_smoother( N_NNRPG_SOUND_SIDH_FADING.wav );
	n_wav_smoother( N_NNRPG_SOUND_FANFARE    .wav );
	n_wav_smoother( N_NNRPG_SOUND_GAMEOVER   .wav );

	{

		n_bmp_1st_fast( &p->bmp_bg, game.sx, game.sy );

		u32 fg = n_bmp_rgb(  10, 10, 10 );
		u32 bg = n_bmp_rgb( 222,255,255 );// n_bmp_rgb( 255,255,255 );

		n_bmp_flush_gradient( &p->bmp_bg, fg,bg, N_BMP_GRADIENT_CIRCLE | N_BMP_GRADIENT_TOPLEFT );

	}

	n_nnrpg_personnel *nina = &p->personnel[ N_NNRPG_PERSONNEL_NINA ];
	n_nnrpg_personnel *nono = &p->personnel[ N_NNRPG_PERSONNEL_NONO ];
	n_nnrpg_personnel *sidh = &p->personnel[ N_NNRPG_PERSONNEL_SIDH ];

	u32 c_a = n_bmp_rgb(   1,  1,  1 );
	u32 cm0 = n_bmp_rgb( 200,  0,  0 );
	u32 cm1 = n_bmp_rgb(   0,100,  0 );
	u32 cm2 = n_bmp_rgb(   0,200,200 );
	u32 c_h = n_bmp_rgb( 200,200,  0 );

	int p0 = 20 + n_game_random( 6 );
	int p1 = 15 + n_game_random( 6 );
	int p2 = 20 + n_game_random( 3 );

	int m0 = 20 + n_game_random( 6 );
	int m1 = 25 + n_game_random( 6 );
	int m2 = 33 + n_game_random( 3 );

	int w0 = 50;
	int w1 = 50;
	int w2 = 47;

	n_nnrpg_personnel_init_literal
	(
		nina,
		"Nina   ",
		p0, m0, w0,
		c_a, cm0, c_h,
		"NNRPG_RC_BMP_NINA", "NNRPG_RC_BMP_NINA_A", "NNRPG_RC_BMP_NINA_M",
		 NNRPG_RC_WAV_0_00 ,  NNRPG_RC_WAV_1      ,  NNRPG_RC_WAV_2
	);

	n_nnrpg_personnel_init_literal
	(
		nono,
		"Nono   ",
		p1, m1, w1,
		c_a, cm1, c_h,
		"NNRPG_RC_BMP_NONO", "NNRPG_RC_BMP_NONO_A", "NNRPG_RC_BMP_NONO_M",
		 NNRPG_RC_WAV_0_01 ,  NNRPG_RC_WAV_1      ,  NNRPG_RC_WAV_2
	);

	n_nnrpg_personnel_init_literal
	(
		sidh,
		"CatSidh",
		p2, m2, w2,
		c_a, cm2, c_h,
		"NNRPG_RC_BMP_SIDH", ""            , ""              ,
		 NNRPG_RC_WAV_0_02 , NNRPG_RC_WAV_1,  NNRPG_RC_WAV_2
	);

//n_bmp_save_literal( &nono->bmp_attack, "ret.bmp" );
//n_bmp_save_literal( &nono->bmp_magic , "ret.bmp" );

	n_game_sound_init_literal( &p->sound_magic_fx[ N_NNRPG_PERSONNEL_NINA ], game.hwnd, "NNRPG_RC_WAV_FX_0" );
	n_game_sound_init_literal( &p->sound_magic_fx[ N_NNRPG_PERSONNEL_NONO ], game.hwnd,  NNRPG_RC_WAV_FX_1  );

	n_wav_smoother( &p->sound_magic_fx[ N_NNRPG_PERSONNEL_NINA ].wav );
	n_wav_smoother( &p->sound_magic_fx[ N_NNRPG_PERSONNEL_NONO ].wav );

	n_nnrpg_window_init_main( &p->window_main );
	n_nnrpg_window_init_main( &p->window_text );

	n_nnrpg_window_bitmap_frame( &p->window_main );
	n_nnrpg_mainwindow( p, N_NNRPG_PERSONNEL_MAX );

	n_game_chara_pos( &p->personnel[ N_NNRPG_PERSONNEL_NINA ].chr, n_nnrpg_metric.chara_0_x, n_nnrpg_metric.chara_0_y );
	n_game_chara_pos( &p->personnel[ N_NNRPG_PERSONNEL_NONO ].chr, n_nnrpg_metric.chara_1_x, n_nnrpg_metric.chara_1_y );
	n_game_chara_pos( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ].chr, n_nnrpg_metric.chara_2_x, n_nnrpg_metric.chara_2_y );


	n_game_input_zero( &p->input );
	n_game_input_init( &p->input, 0 );
	n_game_input_vk2udlr_default( &p->input );
	n_game_input_vk2button( &p->input, VK_SPACE, 0 );
	n_game_input_vk2button( &p->input, VK_SPACE, 1 );
	n_game_input_vk2button( &p->input, VK_SPACE, 2 );
	n_game_input_vk2button( &p->input, VK_SPACE, 3 );
	n_game_input_vk2button( &p->input, VK_SPACE, 4 );
	n_game_input_vk2button( &p->input, VK_SPACE, 5 );


	{ // Star Cache Init

		n_bmp *b = &p->personnel[ N_NNRPG_PERSONNEL_NINA ].bmp_attack;
		s32    u = n_nnrpg_metric.unit_bmp;

		int i = 0;
		while( 1 )
		{

			n_bmp_carboncopy( b, &p->bmp_star[ i ] );

			// [Patched] : n_bmp_matrix_rotate() changes bitmap size

			n_bmp_matrix_rotate( &p->bmp_star[ i ], i * 10, n_bmp_white_invisible, false );
			n_bmp_resizer( &p->bmp_star[ i ], u,u, n_bmp_white_invisible, N_BMP_RESIZER_CENTER );

			i++;
			if ( i >= N_NNRPG_STAR_MAX ) { break; }
		}

	} // Star Cache Init


	{ // Kettle Cache Init

		n_bmp *b = &p->personnel[ N_NNRPG_PERSONNEL_NINA ].bmp_magic;
		s32    u = n_nnrpg_metric.unit_bmp;

		s32 rotate_max   = 40;
		s32 rotate_step  = 10;
		s32 rotate       = -rotate_max;

		int i = 0;
		while( 1 )
		{

			n_bmp_carboncopy( b, &p->bmp_kettle[ i ] );

			// [Patched] : n_bmp_matrix_rotate() changes bitmap size

			n_bmp_matrix_rotate( &p->bmp_kettle[ i ], rotate, n_bmp_white_invisible, false );
			n_bmp_resizer( &p->bmp_kettle[ i ], u,u, n_bmp_white_invisible, N_BMP_RESIZER_CENTER );

			rotate += rotate_step;

			i++;
			if ( i >= N_NNRPG_KETTLE_MAX ) { break; }
		}

	} // Kettle Cache Init



	n_nnrpg_reset( p );


	return;
}

void
n_nnrpg_loop( n_nnrpg *p )
{

	if ( false == n_game_refresh_is_off() ) { return; }


	if ( p->phase == N_NNRPG_PHASE_NONE )
	{

		if ( n_win_is_input( VK_SPACE ) )
		{
			n_nnrpg_reset( p );
		} else {
			if ( p->is_game_over == false ) { n_nnrpg_redraw( p ); }
		}

	} else
	if ( p->phase == N_NNRPG_PHASE_INIT )
	{

		if ( p->transition_onoff == false )
		{

			p->transition_onoff = true;


			n_game_sound_loop( N_NNRPG_SOUND_TRANSITION );


			// [Needed] : VC++ : Win10 : this position is important

			if ( p->midi_init == false )
			{

				p->midi_init = true;

				n_posix_char *name = n_posix_literal( "NNRPG_RC_MID" );
				n_posix_char *sect = n_posix_literal( "DATA" );

				p->midi_tmpname = n_string_path_tmpname_new_literal( ".mid" );

				n_resource_save( name, sect, p->midi_tmpname );
//n_game_hwndprintf_literal( "%s", p->midi );

				n_game_sound_init( N_NNRPG_SOUND_MAIN_BGM, game.hwnd, p->midi_tmpname );

			}


			n_bmp_carboncopy( &p->bmp_bg, &p->transition_bmp_new );
			n_bmp_new( &p->transition_bmp_old, N_BMP_SX( &p->transition_bmp_new ), N_BMP_SY( &p->transition_bmp_new ) );

//n_bmp_save_literal( &p->transition_bmp_new, "ret.bmp" );


			n_nnrpg_metric.canvas = &p->transition_bmp_new;
			n_nnrpg_redraw( p );

			// [!] : "else" is needed

		} else
		if ( n_game_transition( &game.bmp, &p->transition_bmp_old, &p->transition_bmp_new, 2500, N_GAME_TRANSITION_WIPE_Y ) )
		{

			p->transition_onoff = false;


			n_game_sound_loop( N_NNRPG_SOUND_MAIN_BGM );


			n_nnrpg_metric.canvas = &game.bmp;


			p->phase = N_NNRPG_PHASE_BATTLE;

			n_nnrpg_personnel_command_bitmap( &p->personnel[ N_NNRPG_PERSONNEL_NINA ] );
			n_nnrpg_personnel_command_bitmap( &p->personnel[ N_NNRPG_PERSONNEL_NONO ] );
			n_nnrpg_personnel_command_bitmap( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ] );
//n_bmp_save_literal( &personnel[ N_NNRPG_PERSONNEL_NINA ].win.bmp, "ret.bmp" );

			n_nnrpg_personnel_command_set( &p->personnel[ N_NNRPG_PERSONNEL_NINA ], 0 );
			n_nnrpg_personnel_command_set( &p->personnel[ N_NNRPG_PERSONNEL_NONO ], 0 );
			n_nnrpg_personnel_command_set( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ], 0 );

		} else {

			n_nnrpg_redraw( p );

		}


		n_game_refresh_on();

	} else
	if ( p->phase == N_NNRPG_PHASE_BATTLE )
	{

		n_nnrpg_input ( p );
		n_nnrpg_redraw( p );


		if ( n_game_sound_timer( N_NNRPG_SOUND_MAIN_BGM ) ) { n_game_sound_loop( N_NNRPG_SOUND_MAIN_BGM ); }

//n_game_hwndprintf_literal( " Battle : %d ", p->redraw );
		if ( p->redraw == N_NNRPG_REDRAW_NONE )
		{

			if (
				( p->personnel[ N_NNRPG_PERSONNEL_NINA ].hp <= 0 )
				&&
				( p->personnel[ N_NNRPG_PERSONNEL_NONO ].hp <= 0 )
			)
			{

				p->phase = N_NNRPG_PHASE_GAMEOVER;

			} else
			if ( p->personnel[ N_NNRPG_PERSONNEL_SIDH ].hp <= 0 )
			{

				p->phase = N_NNRPG_PHASE_FANFARE;

			}

		}

	} else
	if ( p->phase == N_NNRPG_PHASE_FANFARE )
	{

		static int phase = N_NNRPG_END_PHASE_NONE;

		if ( phase == N_NNRPG_END_PHASE_NONE )
		{

			if ( p->transition_onoff == false )
			{

				p->transition_onoff = true;


				n_game_sound_loop( N_NNRPG_SOUND_SIDH_FADING );


				n_nnrpg_personnel *ps = &p->personnel[ N_NNRPG_PERSONNEL_SIDH ];
				s32                 x = ps->chr.x;
				s32                 y = ps->chr.y;
				s32                sx = ps->chr.sx;
				s32                sy = ps->chr.sy; sy += (double) sy * 0.33;

				n_bmp_new_fast( &p->transition_bmp_old, sx,sy );
				n_bmp_new_fast( &p->transition_bmp_new, sx,sy );

				n_bmp_fastcopy( &game.bmp , &p->transition_bmp_old, x,y,sx,sy, 0,0 );
				n_bmp_fastcopy( &p->bmp_bg, &p->transition_bmp_new, x,y,sx,sy, 0,0 );

				n_game_transition_offset_x = x;
				n_game_transition_offset_y = y;

			} else
			if ( n_game_transition( &game.bmp, &p->transition_bmp_old, &p->transition_bmp_new, 1000, N_GAME_TRANSITION_FADE ) )
			{

				p->transition_onoff = false;

				n_game_sound_stop( N_NNRPG_SOUND_MAIN_BGM );
				n_game_sound_loop( N_NNRPG_SOUND_FANFARE  );

				phase = N_NNRPG_END_PHASE_DONE;

			} else {

				n_nnrpg_redraw( p );

			}

		} else
		if ( phase == N_NNRPG_END_PHASE_DONE )
		{

			if ( n_game_sound_timer( N_NNRPG_SOUND_FANFARE ) )
			{

				n_game_transition_offset_x = 0;
				n_game_transition_offset_y = 0;

				p->phase = N_NNRPG_PHASE_NONE;

				phase = N_NNRPG_END_PHASE_NONE;

			}

			n_nnrpg_redraw( p );

		}

		n_game_refresh_on();

	} else
	if ( p->phase == N_NNRPG_PHASE_GAMEOVER )
	{
//n_game_hwndprintf_literal( " Game Over : %d ", p->redraw );

		static int phase = N_NNRPG_END_PHASE_NONE;

		if ( phase == N_NNRPG_END_PHASE_NONE )
		{

			if ( p->transition_onoff == false )
			{

				p->transition_onoff = true;

				n_game_sound_stop( N_NNRPG_SOUND_MAIN_BGM );

				n_bmp_carboncopy( &game.bmp, &p->transition_bmp_old );
				n_bmp_carboncopy( &game.bmp, &p->transition_bmp_new );

				n_bmp_flush_grayscale( &p->transition_bmp_new );

			} else
			if ( n_game_transition( &game.bmp, &p->transition_bmp_old, &p->transition_bmp_new, 1000, N_GAME_TRANSITION_FADE ) )
			{

				p->transition_onoff = false;

				n_game_sound_loop( N_NNRPG_SOUND_GAMEOVER );

				phase = N_NNRPG_END_PHASE_DONE;

			}

			n_game_refresh_on();

		} else
		if ( phase == N_NNRPG_END_PHASE_DONE )
		{

			if ( n_game_sound_timer( N_NNRPG_SOUND_GAMEOVER ) )
			{

				p->phase = N_NNRPG_PHASE_NONE;

				p->is_game_over = true;

				phase = N_NNRPG_END_PHASE_NONE;

			}

		}

	}


	return;
}

void
n_nnrpg_exit( n_nnrpg *p )
{

	n_game_sound_exit( N_NNRPG_SOUND_MAIN_BGM );

	n_posix_unlink( p->midi_tmpname );
	n_string_path_free( p->midi_tmpname );


	int i = 0;
	while( 1 )
	{

		n_game_sound_exit( &p->sound[ i ] );

		i++;
		if ( i >= N_NNRPG_SOUND_MAX ) { break; }
	}

	n_game_sound_exit( &p->sound_magic_fx[ N_NNRPG_PERSONNEL_NINA ] );
	n_game_sound_exit( &p->sound_magic_fx[ N_NNRPG_PERSONNEL_NONO ] );


	{ // Star Cache Exit

		int i = 0;
		while( 1 )
		{

			n_bmp_free( &p->bmp_star[ i ] );

			i++;
			if ( i >= N_NNRPG_STAR_MAX ) { break; }
		}

	} // Star Cache Exit


	{ // Kettle Cache Exit

		int i = 0;
		while( 1 )
		{

			n_bmp_free( &p->bmp_kettle[ i ] );

			i++;
			if ( i >= N_NNRPG_KETTLE_MAX ) { break; }
		}

	} // Kettle Cache Exit


	n_bmp_free( &p->bmp_bg );

	n_bmp_free( &p->transition_bmp_old );
	n_bmp_free( &p->transition_bmp_new );

	n_nnrpg_window_exit( &p->window_main );
	n_nnrpg_window_exit( &p->window_text );

	n_nnrpg_personnel_exit( &p->personnel[ N_NNRPG_PERSONNEL_NINA ] );
	n_nnrpg_personnel_exit( &p->personnel[ N_NNRPG_PERSONNEL_NONO ] );
	n_nnrpg_personnel_exit( &p->personnel[ N_NNRPG_PERSONNEL_SIDH ] );


	n_game_input_exit( &p->input );


	return;
}




#ifndef N_GAMECONSOLE

void
n_game_init( void )
{

	n_nnrpg_zero( &nnrpg );
	n_nnrpg_init( &nnrpg );


	return;
}

void
n_game_loop( void )
{

	if ( n_win_is_input( VK_F5 ) )
	{
		n_nnrpg_exit( &nnrpg );
		n_nnrpg_init( &nnrpg );
		n_game_reset();
	}

	n_nnrpg_loop( &nnrpg );


	return;
}

void
n_game_exit( void )
{

	n_nnrpg_exit( &nnrpg );


	return;
}

#endif // #ifndef N_GAMECONSOLE

