// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/neutral/bmp/all.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_checkbox.c"
#include "../nonnon/win32/win_colorpicker.c"
#include "../nonnon/win32/win_separator.c"

#include "../nonnon/project/macro.c"




LRESULT CALLBACK
n_paint_clearcanvas_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_colorpicker cp;
	static HWND              hbtn;


	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, 500 );

	break;

	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, true );

		n_win_colorpicker_on_settingchange( &cp );

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, hbtn );

	break;


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_win_colorpicker_zero( &cp );


		// Window

		n_win_init_literal( hwnd, "Clear", "", "" );

		n_win_gui_literal( hwnd, FBTN, "", &hbtn );

		n_win_text_set( hbtn, n_project_string_go );

		n_win_colorpicker_init( &cp, hwnd );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW    );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		n_win_iconbutton_init( hwnd, hbtn );


		n_project_defaultbutton( hbtn );
		SetFocus( hbtn );

		n_win_stdfont_init( &hbtn, 1 );


		nwclr_refresh( &cp, 255,255,255,255 );


		// Size

		{

		const bool redraw = true;


		s32 ctl,ico,m;
		n_win_stdsize( hwnd, &ctl, &ico, &m );

		s32 gap = m * 2;
		s32 csx = ( ico * 5 ) + ( gap * 4 );
		s32 csy = ( ctl * ( 4 + 1 ) );

		s32 patch_csx = csx + m;
		s32 patch_csy = csy + m;

		n_win_set_patch( hwnd, &patch_csx, &patch_csy, 7, 7 );

		n_win_set( hwnd, NULL, patch_csx,patch_csy, N_WIN_SET_CENTERING );

		s32 clr = ctl * 4;

		nwclr_move( &cp  , 0, ( ctl * 0 ), csx,clr, redraw );
		n_win_move(  hbtn, 0, ( ctl * 4 ), csx,ctl, redraw );

		}


		// Display

		ShowWindow( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, false );
		EnableWindow( hwnd_main, false );

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == hbtn )
		{

			u32 color = n_bmp_argb( cp.a, cp.r, cp.g, cp.b );

			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{
				n_bmp_flush( &n_paint_bmp_data, color );
			} else {
				n_bmp_flush( &n_paint_bmp_grab, color );
			}

			n_paint_refresh_all();

			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		}

	break;


	case WM_CLOSE :

		EnableWindow( hwnd_tool, true );
		EnableWindow( hwnd_main, true );

		ShowWindow( hwnd, SW_HIDE );


		n_win_stdfont_exit( &hbtn, 1 );

		n_win_colorpicker_exit( &cp );

		n_win_iconbutton_exit( hwnd, hbtn );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}

	nwclr_proc( hwnd, msg, wparam, lparam, &cp );

	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, hbtn );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

LRESULT CALLBACK
n_paint_colorreplacer_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_colorpicker cp_f;
	static n_win_colorpicker cp_t;
	static HWND              hbtn;
	static HWND              hhr1;
	static HWND              hhr2;
	static HWND              hhr3;


	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, 500 );

	break;

	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, true );

		n_win_refresh( hhr1, true );
		n_win_refresh( hhr2, true );
		n_win_refresh( hhr3, true );

		n_win_colorpicker_on_settingchange( &cp_f );
		n_win_colorpicker_on_settingchange( &cp_t );

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, hbtn );

	break;


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_win_colorpicker_zero( &cp_f );
		n_win_colorpicker_zero( &cp_t );


		// Window

		n_win_init_literal( hwnd, "Color Replacer", "", "" );

		n_win_gui_literal( hwnd, CANVAS, "From", &hhr1 );
		n_win_gui_literal( hwnd, CANVAS, "To",   &hhr2 );
		n_win_gui_literal( hwnd, CANVAS, "",     &hhr3 );
		n_win_gui_literal( hwnd,   FBTN, "",     &hbtn );

		n_win_text_set( hbtn, n_project_string_go );

		n_win_colorpicker_init( &cp_f, hwnd );
		n_win_colorpicker_init( &cp_t, hwnd );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW    );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		n_win_iconbutton_init( hwnd, hbtn );


		n_project_defaultbutton( hbtn );
		SetFocus( hbtn );


		n_win_stdfont_init( &hhr1, 1 );
		n_win_stdfont_init( &hhr2, 1 );
		n_win_stdfont_init( &hhr3, 1 );
		n_win_stdfont_init( &hbtn, 1 );


		nwclr_refresh( &cp_f, cp.a, cp.r, cp.g, cp.b );
		nwclr_refresh( &cp_t, cp.a, cp.r, cp.g, cp.b );


		// Size

		{

		const bool redraw = true;


		s32 ctl,ico,m;
		n_win_stdsize( hwnd, &ctl, &ico, &m );


		s32 gap = m * 2;
		s32 csx = ( ico * 5 ) + ( gap * 4 );
		s32 csy = ( ctl * ( 1 + 4 + 1 + 4 + 1 + 1 ) );

		s32 patch_csx = csx + m;
		s32 patch_csy = csy + m;

		n_win_set_patch( hwnd, &patch_csx, &patch_csy, 7, 7 );

		n_win_set( hwnd, NULL, patch_csx,patch_csy, N_WIN_SET_CENTERING );

		s32 clr = ctl * 4;

		n_win_move(  hhr1, 0, ( ctl *  0 ), csx,ctl, redraw );
		nwclr_move( &cp_f, 0, ( ctl *  1 ), csx,clr, redraw );
		n_win_move(  hhr2, 0, ( ctl *  5 ), csx,ctl, redraw );
		nwclr_move( &cp_t, 0, ( ctl *  6 ), csx,clr, redraw );
		n_win_move(  hhr3, 0, ( ctl * 10 ), csx,ctl, redraw );
		n_win_move(  hbtn, 0, ( ctl * 11 ), csx,ctl, redraw );

		}


		// Display

		ShowWindow( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, false );
		EnableWindow( hwnd_main, false );

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == hbtn )
		{

			u32 f = n_bmp_argb( cp_f.a, cp_f.r, cp_f.g, cp_f.b );
			u32 t = n_bmp_argb( cp_t.a, cp_t.r, cp_t.g, cp_t.b );

			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{
				n_bmp_flush_replacer( &n_paint_bmp_data, f, t );
			} else {
				n_bmp_flush_replacer( &n_paint_bmp_grab, f, t );
			}

			n_paint_refresh_all();

			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		}

	break;


	case WM_CLOSE :

		EnableWindow( hwnd_tool, true );
		EnableWindow( hwnd_main, true );

		ShowWindow( hwnd, SW_HIDE );


		n_win_stdfont_exit( &hhr1, 1 );
		n_win_stdfont_exit( &hhr2, 1 );
		n_win_stdfont_exit( &hhr3, 1 );
		n_win_stdfont_exit( &hbtn, 1 );

		n_win_colorpicker_exit( &cp_f );
		n_win_colorpicker_exit( &cp_t );

		n_win_iconbutton_exit( hwnd, hbtn );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}

	n_win_separator_proc( hwnd, msg, wparam, lparam, hhr1, PS_DOT   );
	n_win_separator_proc( hwnd, msg, wparam, lparam, hhr2, PS_DOT   );
	n_win_separator_proc( hwnd, msg, wparam, lparam, hhr3, PS_SOLID );

	nwclr_proc( hwnd, msg, wparam, lparam, &cp_f );
	nwclr_proc( hwnd, msg, wparam, lparam, &cp_t );

	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, hbtn );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

LRESULT CALLBACK
n_paint_alphatweaker_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND        hbtn;
	static HWND        h_go;
	static n_win_check hchk[ 2 ];


	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, 500 );

	break;

	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, true );

		n_win_check_on_settingchange( &hchk[ 0 ] );
		n_win_check_on_settingchange( &hchk[ 1 ] );

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, hbtn );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, h_go );

	break;


	case WM_CREATE :


		// Global

		n_win_check_zero( &hchk[ 0 ] );
		n_win_check_zero( &hchk[ 1 ] );

		n_win_ime_disable( hwnd );


		// Window

		n_win_init_literal( hwnd, "Alpha Tweaker", "", "" );

		n_win_gui_literal( hwnd, FICOBTN, "", &hbtn );
		n_win_gui_literal( hwnd, FBTN   , "", &h_go );

		n_win_check_init_literal( &hchk[ 0 ], hwnd, "Clear"  , 0 );
		n_win_check_init_literal( &hchk[ 1 ], hwnd, "Reverse", 0 );

		n_win_icon_add( hbtn, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 1 );

		n_win_text_set( h_go, n_project_string_go );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW    );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		n_win_iconbutton_init( hwnd, hbtn );
		n_win_iconbutton_init( hwnd, h_go );


		n_project_defaultbutton( h_go );
		SetFocus( h_go );


		n_win_stdfont_init( &hbtn, 1 );
		n_win_stdfont_init( &h_go, 1 );


		// Size

		{

		const bool redraw = true;


		s32 ctl,ico,m;
		n_win_stdsize( hwnd, &ctl, &ico, &m );
		ico = n_posix_max_s32( ico, ctl * 2 );


		s32 csy = ( ctl * 3 );
		s32 csx = ( csy * 3 );

		s32 patch_csx = csx + m;
		s32 patch_csy = csy + m;

		n_win_set_patch( hwnd, &patch_csx, &patch_csy, 7, 7 );

		n_win_set( hwnd, NULL, patch_csx,patch_csy, N_WIN_SET_CENTERING );


		n_win_move( hbtn          ,     0,           0, ico,ico, redraw );
		n_win_move( hchk[ 0 ].hwnd, 2*ico, ( ctl * 0 ), csx,ctl, redraw );
		n_win_move( hchk[ 1 ].hwnd, 2*ico, ( ctl * 1 ), csx,ctl, redraw );
		n_win_move( h_go          ,     0, ( ctl * 2 ), csx,ctl, redraw );

		}


		// Display

		ShowWindow( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, false );
		EnableWindow( hwnd_main, false );

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == h_go )
		{

			if ( n_win_check_is_checked( &hchk[ 0 ] ) )
			{
				n_paint_filter( N_PAINT_FILTER_ALPHA_CLR );
			}

			if ( n_win_check_is_checked( &hchk[ 1 ] ) )
			{
				n_paint_filter( N_PAINT_FILTER_ALPHA_REV );
			}


			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		}

	break;


	case WM_CLOSE :

		EnableWindow( hwnd_tool, true );
		EnableWindow( hwnd_main, true );

		ShowWindow( hwnd, SW_HIDE );


		// [Needed] : HICON will leak

		n_win_icon_del( hbtn );


		n_win_iconbutton_exit( hwnd, hbtn );

		n_win_check_exit( &hchk[ 0 ] );
		n_win_check_exit( &hchk[ 1 ] );


		n_win_stdfont_exit( &hbtn, 1 );
		n_win_stdfont_exit( &h_go, 1 );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	n_win_check_proc( hwnd, msg, wparam, lparam, &hchk[ 0 ] );
	n_win_check_proc( hwnd, msg, wparam, lparam, &hchk[ 1 ] );

	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, hbtn );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, h_go );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

